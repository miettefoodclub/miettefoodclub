window.MIETTE_CONFIG={supabaseUrl:"",supabaseKey:"",contactEmail:"miettefoodclub@gmail.com"};
